import Link from "next/link";
import {
  ArrowRight,
  BadgeCheck,
  BriefcaseBusiness,
  CheckCircle2,
  FileCheck2,
  Scale,
  ShieldCheck,
  Sparkles,
  UsersRound,
  type LucideIcon,
} from "lucide-react";
import { FadeIn, Stagger, StaggerItem } from "@/components/common/Motion";
import type { WebsiteSettings } from "@/lib/site-settings-schema";
import { AnimatedHeroVisual } from "./AnimatedHeroVisual";

export function HeroSection({ settings }: { settings: WebsiteSettings }) {
  const trustBadges = [
    {
      value: settings.trust_badge_1_value,
      label: settings.trust_badge_1_label,
      icon: Scale,
    },
    {
      value: settings.trust_badge_2_value,
      label: settings.trust_badge_2_label,
      icon: BadgeCheck,
    },
    {
      value: settings.trust_badge_3_value,
      label: settings.trust_badge_3_label,
      icon: BriefcaseBusiness,
    },
  ].filter((badge) => badge.value && badge.label);

  const highlights = [
    {
      title: "Atendimento estratégico",
      description: "Leitura técnica do cenário e dos próximos passos.",
      icon: ShieldCheck,
    },
    {
      title: "Comunicação clara",
      description: "Retorno objetivo, organizado e sem promessas indevidas.",
      icon: FileCheck2,
    },
    {
      title: "Sigilo e cuidado",
      description: "Confidencialidade em todas as etapas do contato.",
      icon: UsersRound,
    },
  ];

  return (
    <section className="relative isolate overflow-hidden bg-hero-modern pt-10 text-navy sm:pt-14 lg:pt-16">
      <div className="hero-glow hero-glow-left" />
      <div className="hero-glow hero-glow-right" />
      <div className="hero-orb hero-orb-one" />
      <div className="hero-orb hero-orb-two" />

      <div className="relative z-10 mx-auto w-full max-w-[1480px] px-5 pb-10 sm:px-8 lg:px-12 lg:pb-14 xl:px-16">
        <div className="grid min-h-[calc(100svh-110px)] items-center gap-12 py-10 lg:grid-cols-[0.92fr_1.08fr] lg:gap-14 lg:py-14 xl:gap-20">
          <div className="max-w-3xl">
            <Stagger className="mb-6 flex flex-wrap gap-2" trigger="load" stagger={0.06}>
              {[
                ["Consultoria jurídica moderna", ShieldCheck],
                ["Empresas e pessoas", BriefcaseBusiness],
                ["Comunicação clara", CheckCircle2],
              ].map(([label, Icon]) => {
                const ChipIcon = Icon as typeof ShieldCheck;
                return (
                  <StaggerItem key={String(label)}>
                    <span className="inline-flex items-center gap-2 rounded-full border border-navy/[0.10] bg-white/[0.78] px-3 py-1.5 text-xs font-bold text-navy/[0.76] shadow-[0_8px_28px_rgba(7,20,33,0.07)] backdrop-blur-xl">
                      <ChipIcon className="size-3.5 text-gold-dark" />
                      {String(label)}
                    </span>
                  </StaggerItem>
                );
              })}
            </Stagger>

            <FadeIn trigger="load" delay={0.08} y={18}>
              <h1 className="max-w-4xl text-4xl font-black leading-[0.98] tracking-[-0.055em] text-navy text-balance sm:text-6xl lg:text-[5rem] xl:text-[5.7rem]">
                {settings.hero_title}
              </h1>
            </FadeIn>

            <FadeIn trigger="load" delay={0.16} y={16}>
              <p className="mt-6 max-w-2xl text-base leading-relaxed text-graphite-soft sm:text-xl">
                {settings.hero_subtitle}
              </p>
            </FadeIn>

            <FadeIn trigger="load" delay={0.24} y={14}>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <Link
                  href={settings.hero_primary_cta_url || "/contato"}
                  className="group inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-navy px-7 text-sm font-bold text-white shadow-[0_18px_48px_rgba(7,20,33,0.22)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-navy-secondary hover:shadow-[0_24px_70px_rgba(7,20,33,0.28)]"
                >
                  {settings.hero_primary_cta_text}
                  <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
                <Link
                  href={settings.hero_secondary_cta_url || "/areas"}
                  className="inline-flex h-14 items-center justify-center rounded-2xl border border-navy/[0.10] bg-white/[0.80] px-7 text-sm font-bold text-navy shadow-[0_12px_34px_rgba(7,20,33,0.07)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:border-champagne/70 hover:bg-white hover:shadow-[0_18px_48px_rgba(7,20,33,0.10)]"
                >
                  {settings.hero_secondary_cta_text}
                </Link>
              </div>
            </FadeIn>

            {trustBadges.length > 0 && (
              <Stagger
                className="mt-10 grid max-w-2xl gap-3 sm:grid-cols-3"
                trigger="load"
                delay={0.32}
              >
                {trustBadges.map((stat) => (
                  <StaggerItem key={`${stat.value}-${stat.label}`}>
                    <TrustStat
                      icon={stat.icon}
                      value={stat.value}
                      label={stat.label}
                    />
                  </StaggerItem>
                ))}
              </Stagger>
            )}
          </div>

          <FadeIn trigger="load" delay={0.18} y={18}>
            <AnimatedHeroVisual settings={settings} />
          </FadeIn>
        </div>

        <Stagger
          className="grid overflow-hidden rounded-[1.75rem] border border-navy/[0.10] bg-navy text-white shadow-[0_26px_90px_rgba(7,20,33,0.18)] md:grid-cols-3"
          trigger="load"
          delay={0.42}
          stagger={0.08}
        >
          {highlights.map((item) => (
            <StaggerItem key={item.title}>
              <HeroFeature
                icon={item.icon}
                title={item.title}
                description={item.description}
              />
            </StaggerItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}

function TrustStat({
  icon: Icon,
  value,
  label,
}: {
  icon: LucideIcon;
  value: string;
  label: string;
}) {
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-navy/[0.10] bg-white/[0.78] p-5 shadow-[0_18px_42px_rgba(7,20,33,0.08)] backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:border-champagne/70 hover:bg-white">
      <span className="absolute right-4 top-4 flex size-10 items-center justify-center rounded-2xl bg-navy/[0.04] text-gold-dark transition-colors group-hover:bg-champagne group-hover:text-navy">
        <Icon className="size-4" />
      </span>
      <p className="text-3xl font-black leading-none tracking-[-0.04em] text-navy">
        {value}
      </p>
      <p className="mt-3 max-w-28 text-sm font-semibold leading-snug text-muted-foreground">
        {label}
      </p>
    </div>
  );
}

function HeroFeature({
  icon: Icon,
  title,
  description,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
}) {
  return (
    <div className="flex min-h-28 items-center gap-4 border-white/[0.10] px-5 py-5 md:border-r md:last:border-r-0 lg:px-8">
      <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl border border-white/[0.10] bg-white/[0.08] text-champagne shadow-sm">
        <Icon className="size-5" />
      </span>
      <span className="min-w-0">
        <span className="block text-sm font-bold text-white">{title}</span>
        <span className="mt-1 block text-sm leading-relaxed text-white/[0.62]">
          {description}
        </span>
      </span>
      <Sparkles className="ml-auto hidden size-4 text-champagne/[0.50] lg:block" />
    </div>
  );
}
