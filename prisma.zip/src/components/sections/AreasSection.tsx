import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { legalAreas } from "@/data/areas";
import { AreaCard } from "@/components/cards/AreaCard";
import { Container } from "@/components/common/Container";
import { Stagger, StaggerItem } from "@/components/common/Motion";
import { SectionHeader } from "@/components/common/SectionHeader";

export function AreasSection() {
  return (
    <section
      id="areas-home"
      className="relative overflow-hidden bg-[linear-gradient(180deg,#fffdf8_0%,#f7f4ee_48%,#fffdf8_100%)] py-20 sm:py-28"
    >
      <div className="absolute left-[-10%] top-8 size-72 rounded-full bg-champagne/10 blur-3xl" />
      <div className="absolute right-[-12%] bottom-12 size-80 rounded-full bg-navy/5 blur-3xl" />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      <Container size="wide" className="relative z-10">
        <SectionHeader
          eyebrow="Áreas de atuação"
          title="Soluções jurídicas para cada etapa da sua jornada."
          description="Atuação consultiva e contenciosa com leitura técnica, estratégia clara e experiência digital pensada para decisões melhores."
          align="left"
          action={
            <Link
              href="/areas"
              className="group inline-flex h-12 items-center gap-2 rounded-2xl border border-navy/10 bg-white px-5 text-sm font-bold text-navy shadow-sm transition-all hover:-translate-y-0.5 hover:border-champagne/70 hover:shadow-premium"
            >
              Ver todas as áreas
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
            </Link>
          }
        />

        <Stagger className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {legalAreas.slice(0, 10).map((area) => (
            <StaggerItem key={area.slug}>
              <AreaCard area={area} />
            </StaggerItem>
          ))}
        </Stagger>
      </Container>
    </section>
  );
}
