import Link from "next/link";
import {
  ArrowRight,
  Briefcase,
  Building2,
  FileText,
  Heart,
  Home,
  Monitor,
  Receipt,
  Scale,
  Shield,
  ShoppingBag,
} from "lucide-react";
import type { LegalArea } from "@/types";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Scale,
  Briefcase,
  Shield,
  Heart,
  ShoppingBag,
  Building2,
  Home,
  Receipt,
  Monitor,
  FileText,
};

interface AreaCardProps {
  area: LegalArea;
  variant?: "compact" | "full";
}

export function AreaCard({ area, variant = "compact" }: AreaCardProps) {
  const Icon = iconMap[area.icon] || Scale;
  const isFull = variant === "full";

  return (
    <Link
      href={`/areas/${area.slug}`}
      className={
        isFull
          ? "modern-card-hover group relative flex h-full min-h-72 flex-col overflow-hidden rounded-[1.65rem] border border-navy/[0.10] bg-white/[0.86] p-6 shadow-[0_18px_50px_rgba(7,20,33,0.08)] backdrop-blur-xl hover:border-champagne/70 hover:bg-white hover:shadow-[0_24px_70px_rgba(7,20,33,0.12)]"
          : "modern-card-hover group relative flex min-h-48 flex-col overflow-hidden rounded-[1.55rem] border border-navy/[0.10] bg-white/[0.86] p-5 shadow-[0_18px_50px_rgba(7,20,33,0.08)] backdrop-blur-xl hover:border-champagne/70 hover:bg-white hover:shadow-[0_24px_70px_rgba(7,20,33,0.12)]"
      }
    >
      <span className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-champagne/70 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      <span className="absolute -right-8 -top-8 size-24 rounded-full bg-champagne/[0.10] blur-2xl transition-opacity duration-300 group-hover:opacity-100" />

      <div className="mb-6 flex items-center justify-between gap-4">
        <div className="flex size-12 items-center justify-center rounded-2xl bg-navy text-champagne shadow-[0_12px_28px_rgba(7,20,33,0.15)] transition-all duration-300 group-hover:scale-105 group-hover:bg-champagne group-hover:text-navy">
          <Icon className="size-5" />
        </div>
        <span className="flex size-10 items-center justify-center rounded-full border border-navy/[0.10] bg-white text-muted-foreground transition-all duration-300 group-hover:border-champagne/80 group-hover:text-navy">
          <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5" />
        </span>
      </div>

      <h3 className={isFull ? "text-xl font-black tracking-[-0.03em] text-navy" : "text-base font-black tracking-[-0.02em] text-navy"}>
        {area.name}
      </h3>

      {isFull && (
        <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
          {area.shortDescription}
        </p>
      )}

      {!isFull && (
        <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
          {area.shortDescription}
        </p>
      )}

      <span className="mt-auto inline-flex items-center gap-2 pt-5 text-sm font-black text-navy">
        Saiba mais
        <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
      </span>
    </Link>
  );
}
