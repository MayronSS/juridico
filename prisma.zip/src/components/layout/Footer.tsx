"use client";

import type { ReactNode } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Clock, Mail, MapPin, Phone, Scale, type LucideIcon } from "lucide-react";
import { Container } from "@/components/common/Container";
import { footerNavigation } from "@/data/navigation";
import type { WebsiteSettings } from "@/lib/site-settings-schema";

export function Footer({ settings }: { settings: WebsiteSettings }) {
  const pathname = usePathname();

  if (pathname?.startsWith("/admin")) return null;

  const currentYear = new Date().getFullYear();
  const socialLinks = [
    { label: "Instagram", href: settings.instagram_url },
    { label: "LinkedIn", href: settings.linkedin_url },
    { label: "Facebook", href: settings.facebook_url },
  ].filter((item) => item.href);

  return (
    <footer className="border-t border-border bg-white">
      <Container size="wide" className="py-14 sm:py-20">
        <div className="rounded-3xl bg-navy p-8 text-white shadow-premium-lg sm:p-10">
          <div className="grid gap-10 lg:grid-cols-[1.25fr_0.8fr_0.8fr_1fr]">
            <div>
              <Link href="/" className="inline-flex items-center gap-3">
                {settings.logo_image_path ? (
                  <Image
                    src={settings.logo_image_path}
                    alt={settings.logo_text || settings.office_name}
                    width={180}
                    height={48}
                    className="h-10 w-auto brightness-0 invert"
                  />
                ) : (
                  <>
                    <span className="flex size-11 items-center justify-center rounded-2xl bg-white text-navy">
                      <Scale className="size-5" />
                    </span>
                    <span className="text-lg font-semibold leading-none">
                      {settings.logo_text || settings.office_name}
                    </span>
                  </>
                )}
              </Link>
              <p className="mt-6 max-w-sm text-sm leading-relaxed text-white/65">
                {settings.footer_description || settings.short_description}
              </p>

              {socialLinks.length > 0 && (
                <div className="mt-6 flex flex-wrap gap-2">
                  {socialLinks.map((item) => (
                    <a
                      key={item.label}
                      href={item.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-full border border-white/10 px-3 py-2 text-xs font-semibold text-white/65 transition-colors hover:border-white/30 hover:text-white"
                    >
                      {item.label}
                    </a>
                  ))}
                </div>
              )}
            </div>

            <FooterColumn title="Institucional" items={footerNavigation.institutional} />

            <div>
              <FooterColumn title="Áreas" items={footerNavigation.areas} />
              <Link
                href="/areas"
                className="mt-4 inline-flex text-sm font-semibold text-champagne transition-colors hover:text-white"
              >
                Ver todas as áreas
              </Link>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-white">Contato</h3>
              <ul className="mt-6 space-y-4">
                <FooterContact icon={Phone}>{settings.phone}</FooterContact>
                <FooterContact icon={Mail}>
                  <a href={`mailto:${settings.contact_email}`} className="hover:text-white">
                    {settings.contact_email}
                  </a>
                </FooterContact>
                <FooterContact icon={MapPin}>
                  <span>{settings.address}</span>
                  <span className="block text-white/45">
                    {settings.city}/{settings.state} - CEP {settings.zip_code}
                  </span>
                </FooterContact>
                <FooterContact icon={Clock}>{settings.business_hours}</FooterContact>
              </ul>
            </div>
          </div>

          <div className="mt-10 grid gap-3 border-t border-white/10 pt-8 sm:grid-cols-2">
            <FooterColumn title="Legal" items={footerNavigation.legal} compact />
            <p className="text-xs leading-relaxed text-white/45 sm:text-right">
              Conteúdo informativo, sem promessa de resultado e sem captação
              ativa de clientela.
            </p>
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground sm:text-left">
          © {currentYear} {settings.office_name}. Todos os direitos reservados.
        </p>
      </Container>
    </footer>
  );
}

function FooterColumn({
  title,
  items,
  compact = false,
}: {
  title: string;
  items: { label: string; href: string }[];
  compact?: boolean;
}) {
  return (
    <div>
      <h3 className="text-sm font-semibold text-white">{title}</h3>
      <ul className={compact ? "mt-3 flex flex-wrap gap-x-4 gap-y-2" : "mt-6 space-y-3"}>
        {items.map((item) => (
          <li key={item.href}>
            <Link
              href={item.href}
              className="text-sm text-white/60 transition-colors hover:text-white"
            >
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

function FooterContact({
  icon: Icon,
  children,
}: {
  icon: LucideIcon;
  children: ReactNode;
}) {
  return (
    <li className="flex items-start gap-3 text-sm leading-relaxed text-white/70">
      <Icon className="mt-0.5 size-4 shrink-0 text-champagne" />
      <span>{children}</span>
    </li>
  );
}
