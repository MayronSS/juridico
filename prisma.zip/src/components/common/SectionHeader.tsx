import type { ReactNode } from "react";
import { FadeIn } from "@/components/common/Motion";
import { cn } from "@/lib/utils";

export function SectionHeader({
  eyebrow,
  title,
  description,
  align = "center",
  inverted = false,
  action,
  className,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  inverted?: boolean;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <FadeIn
      className={cn(
        "flex flex-col gap-5",
        align === "center" ? "items-center text-center" : "items-start text-left",
        action && "sm:flex-row sm:items-end sm:justify-between sm:text-left",
        className
      )}
    >
      <div
        className={cn(
          "max-w-3xl",
          align === "center" && !action && "mx-auto"
        )}
      >
        {eyebrow && (
          <p
            className={cn(
              "mb-3 inline-flex items-center gap-2 rounded-full border border-border/80 bg-white/75 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-navy shadow-sm backdrop-blur",
              inverted && "border-white/10 bg-white/10 text-white/78"
            )}
          >
            <span
              className={cn(
                "h-1.5 w-1.5 rounded-full bg-champagne",
                inverted && "bg-champagne"
              )}
            />
            {eyebrow}
          </p>
        )}
        <h2
          className={cn(
            "text-3xl font-semibold leading-tight text-foreground sm:text-4xl lg:text-5xl",
            inverted && "text-warm-white"
          )}
        >
          {title}
        </h2>
        {description && (
          <p
            className={cn(
              "mt-4 text-base leading-relaxed text-muted-foreground sm:text-lg",
              inverted && "text-warm-white/70"
            )}
          >
            {description}
          </p>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </FadeIn>
  );
}
