import Link from "next/link";
import { ArrowRight, Clock, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { calculateReadingTime, formatDate, truncateText } from "@/lib/utils";

interface PostCardProps {
  post: {
    title: string;
    slug: string;
    excerpt: string | null;
    content?: string;
    coverImage: string | null;
    publishedAt: Date | null;
    createdAt: Date;
    category: {
      name: string;
      slug: string;
    } | null;
    author: {
      name: string;
    };
  };
  variant?: "default" | "featured";
}

export function PostCard({ post, variant = "default" }: PostCardProps) {
  const readingTime = post.content ? calculateReadingTime(post.content) : 3;
  const date = post.publishedAt || post.createdAt;
  const isFeatured = variant === "featured";

  return (
    <Link
      href={`/blog/${post.slug}`}
      className={
        isFeatured
          ? "modern-card-hover group grid overflow-hidden rounded-[2rem] border border-navy/[0.10] bg-white/[0.88] shadow-[0_22px_70px_rgba(7,20,33,0.10)] backdrop-blur-xl hover:border-champagne/70 hover:bg-white hover:shadow-[0_32px_90px_rgba(7,20,33,0.14)] sm:grid-cols-[0.92fr_1.08fr] lg:col-span-2"
          : "modern-card-hover group flex h-full flex-col overflow-hidden rounded-[1.65rem] border border-navy/[0.10] bg-white/[0.88] shadow-[0_18px_50px_rgba(7,20,33,0.08)] backdrop-blur-xl hover:border-champagne/70 hover:bg-white hover:shadow-[0_24px_70px_rgba(7,20,33,0.12)]"
      }
    >
      <div className={isFeatured ? "relative min-h-72 bg-mist" : "relative h-48 bg-mist"}>
        <div className="absolute inset-x-0 top-0 z-10 h-px bg-gradient-to-r from-transparent via-champagne/80 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
        {post.coverImage ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={post.coverImage}
            alt=""
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.035]"
          />
        ) : (
          <div className="flex h-full items-center justify-center bg-[radial-gradient(circle_at_30%_20%,rgba(200,169,106,0.18),transparent_32%),linear-gradient(135deg,#f8f5ef,#ffffff)]">
            <div className="flex size-16 items-center justify-center rounded-3xl bg-navy text-champagne shadow-[0_18px_42px_rgba(7,20,33,0.18)]">
              <FileText className="size-7" />
            </div>
          </div>
        )}
      </div>

      <div className={isFeatured ? "flex flex-col p-7 sm:p-8" : "flex flex-1 flex-col p-6"}>
        <div className="mb-5 flex flex-wrap items-center gap-3">
          {post.category && (
            <Badge variant="secondary" className="rounded-full px-3 py-1 text-xs font-bold">
              {post.category.name}
            </Badge>
          )}
          <span className="text-xs font-semibold text-muted-foreground">
            {formatDate(date)}
          </span>
        </div>

        <h2
          className={
            isFeatured
              ? "text-2xl font-black leading-tight tracking-[-0.04em] text-navy transition-colors sm:text-4xl"
              : "text-xl font-black leading-tight tracking-[-0.035em] text-navy transition-colors"
          }
        >
          {post.title}
        </h2>

        {post.excerpt && (
          <p
            className={
              isFeatured
                ? "mt-4 line-clamp-4 text-base leading-relaxed text-muted-foreground"
                : "mt-4 line-clamp-3 text-sm leading-relaxed text-muted-foreground"
            }
          >
            {truncateText(post.excerpt, isFeatured ? 260 : 170)}
          </p>
        )}

        <div className="mt-auto flex items-center justify-between gap-4 border-t border-navy/[0.10] pt-5">
          <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
            <Clock className="size-3.5" />
            <span>{readingTime} min de leitura</span>
          </div>
          <span className="inline-flex items-center gap-2 text-sm font-black text-navy">
            Ler artigo
            <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
          </span>
        </div>
      </div>
    </Link>
  );
}
