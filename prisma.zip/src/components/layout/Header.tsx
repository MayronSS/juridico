"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth, UserButton } from "@clerk/nextjs";
import { motion } from "framer-motion";
import { ArrowRight, Menu, Scale } from "lucide-react";
import { mainNavigation } from "@/data/navigation";
import { cn } from "@/lib/utils";
import type { WebsiteSettings } from "@/lib/site-settings-schema";
import { MobileMenu } from "./MobileMenu";

export function Header({
  userRole,
  settings,
}: {
  userRole?: string;
  settings: WebsiteSettings;
}) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const pathname = usePathname();
  const { isSignedIn } = useAuth();
  const isAdminOrEditor = userRole === "ADMIN" || userRole === "EDITOR";

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 8);
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  if (pathname?.startsWith("/admin")) return null;

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 border-b transition-all duration-300",
          isScrolled
            ? "border-border/80 bg-white/95 shadow-sm backdrop-blur-xl"
            : "border-border/70 bg-white/90 backdrop-blur-xl"
        )}
      >
        <div className="mx-auto flex h-[76px] w-full max-w-[1540px] items-center justify-between gap-6 px-5 sm:px-8 lg:px-12 xl:px-16">
          <Link href="/" className="group flex min-w-0 items-center gap-3">
            {settings.logo_image_path ? (
              <Image
                src={settings.logo_image_path}
                alt={settings.logo_text || settings.office_name}
                width={188}
                height={48}
                className="h-10 w-auto transition-opacity group-hover:opacity-80"
                priority
              />
            ) : (
              <>
                <span className="flex size-10 items-center justify-center rounded-lg bg-navy text-white shadow-sm">
                  <Scale className="size-5" />
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-base font-semibold leading-none text-navy sm:text-lg">
                    {settings.logo_text || settings.office_name}
                  </span>
                  <span className="mt-1 hidden text-xs font-medium uppercase tracking-[0.18em] text-gold-dark sm:block">
                    Juridico estrategico
                  </span>
                </span>
              </>
            )}
          </Link>

          <nav className="hidden items-center gap-7 lg:flex">
            {mainNavigation.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "relative py-2 text-sm font-semibold transition-colors",
                    isActive
                      ? "text-navy"
                      : "text-muted-foreground hover:text-navy"
                  )}
                >
                  <span>{item.label}</span>
                  {isActive && (
                    <motion.span
                      layoutId="public-nav-active"
                      className="absolute inset-x-0 -bottom-1 h-0.5 rounded-full bg-champagne"
                      transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
                    />
                  )}
                </Link>
              );
            })}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            {!isSignedIn ? (
              <Link
                href="/login"
                className="inline-flex h-11 items-center rounded-lg border border-border bg-white px-4 text-sm font-semibold text-navy shadow-sm transition-all hover:-translate-y-0.5 hover:border-champagne/70 hover:shadow-premium"
              >
                Area do Cliente
              </Link>
            ) : (
              <>
                <Link
                  href={isAdminOrEditor ? "/admin" : "/minha-conta"}
                  className="inline-flex h-11 items-center rounded-lg border border-border bg-white px-4 text-sm font-semibold text-navy shadow-sm transition-all hover:-translate-y-0.5 hover:border-champagne/70 hover:shadow-premium"
                >
                  {isAdminOrEditor ? "Painel Admin" : "Minha Conta"}
                </Link>
                <div className="rounded-full border border-border bg-white p-1 shadow-sm">
                  <UserButton
                    appearance={{
                      elements: {
                        avatarBox: "h-8 w-8",
                      },
                    }}
                  />
                </div>
              </>
            )}

            <Link
              href="/contato"
              className="group inline-flex h-11 items-center gap-2 rounded-lg bg-navy px-5 text-sm font-semibold text-white shadow-premium transition-all hover:-translate-y-0.5 hover:bg-navy-secondary hover:shadow-premium-lg"
            >
              Fale com o Escritorio
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
          </div>

          <button
            type="button"
            onClick={() => setIsMobileOpen(true)}
            className="rounded-lg border border-border bg-white p-2.5 text-navy shadow-sm transition-colors hover:bg-surface-soft lg:hidden"
            aria-label="Abrir menu de navegacao"
          >
            <Menu className="size-5" />
          </button>
        </div>
      </header>

      <div className="h-[76px]" />

      <MobileMenu
        isOpen={isMobileOpen}
        onClose={() => setIsMobileOpen(false)}
        userRole={userRole}
        settings={settings}
      />
    </>
  );
}
