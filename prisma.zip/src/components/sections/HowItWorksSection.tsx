import { FileCheck, Handshake, MessageSquare, Search } from "lucide-react";
import { Container } from "@/components/common/Container";
import { Stagger, StaggerItem } from "@/components/common/Motion";
import { SectionHeader } from "@/components/common/SectionHeader";

const steps = [
  {
    icon: MessageSquare,
    title: "Contato inicial",
    description:
      "O primeiro contato reúne informações objetivas para entender a natureza da demanda.",
  },
  {
    icon: Search,
    title: "Análise preliminar",
    description:
      "A equipe avalia contexto, documentos disponíveis, riscos e pontos que precisam de esclarecimento.",
  },
  {
    icon: FileCheck,
    title: "Orientação técnica",
    description:
      "Você recebe uma leitura clara das alternativas, limites, prazos e próximos passos possíveis.",
  },
  {
    icon: Handshake,
    title: "Acompanhamento",
    description:
      "Havendo contratação, o trabalho segue com comunicação organizada e acompanhamento responsável.",
  },
];

export function HowItWorksSection() {
  return (
    <section
      id="metodo-home"
      className="relative overflow-hidden bg-[linear-gradient(135deg,#071421_0%,#102335_55%,#152d43_100%)] py-20 text-white sm:py-28"
    >
      <div className="absolute inset-0 surface-grid opacity-[0.08]" />
      <Container size="wide">
        <SectionHeader
          eyebrow="Método"
          title="Como funciona o atendimento"
          description="Um fluxo objetivo para transformar dúvidas jurídicas em decisões mais informadas, sem promessa de resultado e com comunicação profissional."
          inverted
        />

        <Stagger className="relative mt-14 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="absolute left-0 right-0 top-9 hidden h-px bg-white/14 lg:block" />
          {steps.map((step, index) => {
            const Icon = step.icon;

            return (
              <StaggerItem key={step.title}>
                <div className="relative rounded-2xl border border-white/10 bg-white/[0.08] p-6 shadow-premium backdrop-blur transition-all hover:-translate-y-1 hover:border-champagne/40 hover:bg-white/[0.11] hover:shadow-premium-lg">
                  <div className="mb-7 flex items-center justify-between">
                    <div className="flex size-14 items-center justify-center rounded-2xl bg-champagne text-navy shadow-sm">
                      <Icon className="size-6" />
                    </div>
                    <span className="text-3xl font-semibold leading-none text-white/10">
                      0{index + 1}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold leading-tight text-white">
                    {step.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-white/66">
                    {step.description}
                  </p>
                </div>
              </StaggerItem>
            );
          })}
        </Stagger>
      </Container>
    </section>
  );
}
