import Link from "next/link";
import { ArrowRight, MessageSquareText } from "lucide-react";
import { Container } from "@/components/common/Container";
import { FadeIn } from "@/components/common/Motion";
import type { WebsiteSettings } from "@/lib/site-settings-schema";

export function FinalCtaSection({ settings }: { settings: WebsiteSettings }) {
  return (
    <section
      id="cta-home"
      className="relative overflow-hidden bg-[linear-gradient(135deg,#071421_0%,#102335_58%,#071421_100%)] py-16 text-white sm:py-24"
    >
      <div className="absolute inset-0 surface-grid opacity-[0.08]" />
      <Container size="wide" className="relative">
        <FadeIn className="border-y border-white/12 py-10 lg:py-14">
          <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
            <div className="max-w-3xl">
              <div className="mb-5 flex size-12 items-center justify-center rounded-xl bg-champagne text-navy shadow-sm">
                <MessageSquareText className="size-5" />
              </div>
              <h2 className="text-3xl font-semibold leading-tight text-white sm:text-4xl lg:text-5xl">
                {settings.final_cta_title}
              </h2>
              <p className="mt-5 text-base leading-relaxed text-white/70 sm:text-lg">
                {settings.final_cta_description}
              </p>
              <p className="mt-5 text-xs leading-relaxed text-white/45">
                O contato nao cria automaticamente uma relacao advogado-cliente.
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row lg:flex-col">
              <Link
                href={settings.hero_primary_cta_url || "/contato"}
                className="group inline-flex h-[52px] items-center justify-center gap-2 rounded-lg bg-champagne px-7 text-sm font-semibold text-navy shadow-premium transition-all hover:-translate-y-0.5 hover:bg-white hover:shadow-premium-lg"
              >
                {settings.hero_primary_cta_text}
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                href={settings.hero_secondary_cta_url || "/areas"}
                className="inline-flex h-[52px] items-center justify-center rounded-lg border border-white/18 bg-white/10 px-7 text-sm font-semibold text-white shadow-sm backdrop-blur transition-all hover:-translate-y-0.5 hover:bg-white hover:text-navy hover:shadow-premium"
              >
                {settings.hero_secondary_cta_text}
              </Link>
            </div>
          </div>
        </FadeIn>
      </Container>
    </section>
  );
}
